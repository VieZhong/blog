var imgNum;
var imgSrcArray = [];
var showPic = function(index){
    $("#lImgContainer").css("left",-$(window).width()*index);
    $(".transparentLayer").show();
    $(".overLayer").show();
};
var hidePic = function(){
    $(".overLayer").hide(50);
    $(".transparentLayer").hide(300);
};

var slider = {
    //判断设备是否支持touch事件
    touch:('ontouchstart' in window) || window.DocumentTouch && document instanceof DocumentTouch,
    //事件
    events:{
        container:$('#lImgContainer'),
        //事件入口，分发
        handleEvent:function(event){
            var self = this;     //this指events对象
            if(event.type == 'touchstart'){
                self.start(event);
            }else if(event.type == 'touchmove'){
                self.move(event);
            }else if(event.type == 'touchend'){
                self.end(event);
            }
        },
        //滑动开始
        start:function(event){
            var self = this;
            var touch = event.originalEvent.touches[0];     //touches数组对象获得屏幕上所有的touch，取第一个touch
            self.startPos = {x:touch.pageX,y:touch.pageY,time:+new Date};    //取第一个touch的坐标值
            self.isScrolling = 0;   //这个参数判断是垂直滚动还是水平滚动
            self.containerLeft = +self.container.css("left").substring(0,self.container.css("left").length-2);
            self.container.bind('touchmove touchend',function(e){
                self.handleEvent(e);
            });
        },
        //移动
        move:function(event){
            //当屏幕有多个touch，就不执行move操作
            if(event.originalEvent.touches.length > 1) return;
            var self = this;
            var touch = event.originalEvent.touches[0];
            self.endPos = {x:touch.pageX - self.startPos.x,y:touch.pageY - self.startPos.y};
            self.isScrolling = Math.abs(self.endPos.x) < Math.abs(self.endPos.y) ? 1:0;    //isScrolling为1时，表示纵向滑动，0为横向滑动
            if(self.isScrolling === 0){
                event.preventDefault();      //阻止触摸事件的默认行为，即阻止滚屏
                self.container.css('left', (self.containerLeft + self.endPos.x) + 'px');
            }
        },
        //滑动释放
        end:function(event){
            var self = this;
            var duration = +new Date - self.startPos.time;    //滑动的持续时间
            if(duration > 120){
                if(self.isScrolling === 0){
                    if(self.endPos.x > 50){ //左移
                        if(self.containerLeft != 0){
                            self.containerLeft += $(window).width();
                        }
                    }else if(self.endPos.x < -50){  //右移
                        if(-self.containerLeft != (self.container.find("img").length-1)*$(window).width()){
                            self.containerLeft -= $(window).width();
                        }
                    }
                    self.container.css('left', self.containerLeft + 'px');
                }
            }else{
                hidePic();
            }
            //解绑事件
            this.container.unbind('touchmove touchend');
        }
    },
    
    //初始化
    init:function(){
        var self = this;     //this指slider对象
        if(!!self.touch){
            self.events.container.bind('touchstart',function(e){
                self.events.handleEvent(e);
            });
        }  
    }
};

var init = function(){
    var screenWidth = $(window).width();
    var screenHeight = $(window).height();
    var tpl = '<div class="lImgContainer-single"><div><img></div></div>';
    var containerHTML = "";
    imgNum = $(".sImgContainer div").length;
    $(".sImgContainer img").each(function(index,img){
        imgSrcArray.push($(img).attr("src"));
    });
    for(var i=imgNum;(i--)>0;containerHTML+=tpl);
    $(".layer").css({'width':screenWidth,'height':screenHeight});
    $("#lImgContainer").css({'width':screenWidth*imgNum,'height':screenHeight});
    $("#lImgContainer").html(containerHTML);
    $(".lImgContainer-single").css({'width':screenWidth,'height':screenHeight});
    $(".lImgContainer-single div").css({'width':screenWidth,'height':screenHeight});
    $(".lImgContainer-single img").each(function(inx,img){
        $(img).attr("src",imgSrcArray[inx]);
    });
    $(".sImgContainer").click(function(e){
        if(e.target.nodeName.toUpperCase() === "IMG"){
            var src = $(e.target).attr("src");
            for(var i=0;i<imgNum;i++){
                if(src === imgSrcArray[i]){
                    showPic(i);
                    break;
                }
            }
        }
    });
    slider.init();
};

$(document).ready(function(){
    init();
});